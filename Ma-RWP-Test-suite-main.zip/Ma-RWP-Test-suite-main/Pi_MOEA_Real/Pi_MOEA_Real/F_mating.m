function MatingPool = F_mating(Population, FunctionValue, FrontValue, KneePoint)
% This function is used for the mating selection

    [N,D] = size(Population);
    Distance = F_AVRank(FunctionValue);
    %-----------------------------------------------------------------------------------------    
  
% Sort the solutions based on their 'FrontValue', 'KneePoint' and 'Crowd'
    FitnessValue = [FrontValue',-KneePoint',Distance];
    [null,Rank] = sortrows(FitnessValue);
    % the final fitness of each solution (the smaller the better)
    FitnessValue(Rank) = 1:N; 
%-----------------------------------------------------------------------------------------     
% Binary tournament mating selection based on 'FitnessValue'
    Parent1    = randi(N,1,ceil(N/2)*2);
    Parent2    = randi(N,1,ceil(N/2)*2);
    MatingPool = [Parent1(FitnessValue(Parent1)<=FitnessValue(Parent2)),...
                  Parent2(FitnessValue(Parent1)>FitnessValue(Parent2))];
    MatingPool = Population(MatingPool,:);
end

