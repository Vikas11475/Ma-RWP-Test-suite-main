function f = F_Real_UC(x,RealWorldProb,M)

%% 4-objective
% Car side impact design problem
if RealWorldProb == 1
    f = zeros(1,M);
    x1 = x(1);
    x2 = x(2);
    x3 = x(3);
    x4 = x(4);
    x5 = x(5);
    x6 = x(6);
    x7 = x(7);

    % First original objective function
    F1 = 1.98 + 4.9 * x1 + 6.67 * x2 + 6.98 * x3 + 4.01 * x4 + 1.78 * x5 + 0.00001 * x6 + 2.73 * x7;

    % Second original objective function
    F2 = 4.72 - 0.5 * x4 - 0.19 * x2 * x3;

    % Third original objective function
    Vmbp = 10.58 - 0.674 * x1 * x2 - 0.67275 * x2;
    Vfd = 16.45 - 0.489 * x3 * x7 - 0.843 * x5 * x6;
    F3 = 0.5 * (Vmbp + Vfd);

    % Constraint functions
    g(1) = 1 -(1.16 - 0.3717 * x2 * x4 - 0.0092928 * x3);
    g(2) = 0.32 -(0.261 - 0.0159 * x1 * x2 - 0.06486 * x1 -  0.019 * x2 * x7 + 0.0144 * x3 * x5 + 0.0154464 * x6);
    g(3) = 0.32 -(0.214 + 0.00817 * x5 - 0.045195 * x1 - 0.0135168 * x1 + 0.03099 * x2 * x6 - 0.018 * x2 * x7  + 0.007176 * x3 + 0.023232 * x3 - 0.00364 * x5 * x6 - 0.018 * x2 * x2);
    g(4) = 0.32 -(0.74 - 0.61 * x2 - 0.031296 * x3 - 0.031872 * x7 + 0.227 * x2 * x2);
    g(5) = 32 -(28.98 + 3.818 * x3 - 4.2 * x1 * x2 + 1.27296 * x6 - 2.68065 * x7);
    g(6) = 32 -(33.86 + 2.95 * x3 - 5.057 * x1 * x2 - 3.795 * x2 - 3.4431 * x7 + 1.45728);
    g(7) =  32 -(46.36 - 9.9 * x2 - 4.4505 * x1);
    g(8) =  4 - f(2);
    g(9) =  9.9 - Vmbp;
    g(10) =  15.7 - Vfd;

    % Calculate the constratint violation values
    g(g>=0)=0;
    g(g<0)=-g(g<0);

    F4 = g(1) + g(2) + g(3) + g(4) + g(5) + g(6) + g(7) + g(8) + g(9) + g(10);


    f(1) = F1;  % minimization
    f(2) = F2; % minimization
    f(3) = F3; % minimization
    f(4) = F4; % minimization
end

% Conceptual marine design
if RealWorldProb == 2
    f = zeros(1,M);
    x_L = x(1);
    x_B = x(2);
    x_D = x(3);
    x_T = x(4);
    x_Vk = x(5);
    x_CB = x(6);

    displacement = 1.025 * x_L * x_B * x_T * x_CB;
    V = 0.5144 * x_Vk;
    g = 9.8065;
    Fn = V / power(g * x_L, 0.5);
    a = (4977.06 * x_CB * x_CB) - (8105.61 * x_CB) + 4456.51;
    b = (-10847.2 * x_CB * x_CB) + (12817.0 * x_CB) - 6960.32;

    power_pb = (power(displacement, 2.0/3.0) * power(x_Vk, 3.0)) / (a + (b * Fn));
    outfit_weight = 1.0 * power(x_L, 0.8) * power(x_B, 0.6) * power(x_D, 0.3) * power(x_CB, 0.1);
    steel_weight = 0.034 * power(x_L ,1.7) * power(x_B ,0.7) * power(x_D ,0.4) * power(x_CB ,0.5);
    machinery_weight = 0.17 * power(power_pb, 0.9);
    light_ship_weight = steel_weight + outfit_weight + machinery_weight;

    ship_cost = 1.3 * ((2000.0 * power(steel_weight, 0.85))  + (3500.0 * outfit_weight) + (2400.0 * power(power_pb, 0.8)));
    capital_costs = 0.2 * ship_cost;

    DWT = displacement - light_ship_weight;

    running_costs = 40000.0 * power(DWT, 0.3);

    round_trip_miles = 5000.0;
    sea_days = (round_trip_miles / 24.0) * x_Vk;
    handling_rate = 8000.0;

    daily_consumption = ((0.19 * power_pb * 24.0) / 1000.0) + 0.2;
    fuel_price = 100.0;
    fuel_cost = 1.05 * daily_consumption * sea_days * fuel_price;
    port_cost = 6.3 * power(DWT, 0.8);

    fuel_carried = daily_consumption * (sea_days + 5.0);
    miscellaneous_DWT = 2.0 * power(DWT, 0.5);

    cargo_DWT = DWT - fuel_carried - miscellaneous_DWT;
    port_days = 2.0 * ((cargo_DWT / handling_rate) + 0.5);
    RTPA = 350.0 / (sea_days + port_days);
    voyage_costs = (fuel_cost + port_cost) * RTPA;
    annual_costs = capital_costs + running_costs + voyage_costs;
    annual_cargo = cargo_DWT * RTPA;

    F1 = annual_costs / annual_cargo;
    F2 = light_ship_weight;
    F3 = annual_cargo;  % f_2 is dealt as a minimization problem

    % Reformulated objective functions
    constraintFuncs(1) = (x_L / x_B) - 6.0;
    constraintFuncs(2) = -(x_L / x_D) + 15.0;
    constraintFuncs(3) = -(x_L / x_T) + 19.0;
    constraintFuncs(4) = 0.45 * power(DWT, 0.31) - x_T;
    constraintFuncs(5) = 0.7 * x_D + 0.7 - x_T;
    constraintFuncs(6) = 50000.0 - DWT;
    constraintFuncs(7) = DWT - 3000.0;
    constraintFuncs(8) = 0.32 - Fn;

    KB = 0.53 * x_T;
    BMT = ((0.085 * x_CB - 0.002) * x_B * x_B) / (x_T * x_CB);
    KG = 1.0 + 0.52 * x_D;
    constraintFuncs(9) = (KB + BMT - KG) - (0.07 * x_B);

    % Calculate the constratint violation values
    constraintFuncs(constraintFuncs>=0)=0;
    constraintFuncs(constraintFuncs<0)=-constraintFuncs(constraintFuncs<0);

    F4 = constraintFuncs(1) + constraintFuncs(2) + constraintFuncs(3) + constraintFuncs(4) + constraintFuncs(5) + constraintFuncs(6) + constraintFuncs(7) + constraintFuncs(8) + constraintFuncs(9);

    f(1) = F1;  % minimization
    f(2) = F2; % minimization
    f(3) = -F3; % maximization
    f(4) = F4; % minimization


end


% Four objective Liquid-rocket single element injector design

if RealWorldProb == 3
    f = zeros(1,M);
    x1 = x(1);
    x2 = x(2);
    x3 = x(3);
    x4 = x(4);

    % First original objective function
    TFmax = 0.692 + 0.477* x1 - 0.687* x2 - 0.080 * x3 - 0.0650 * x4 - 0.167 * (x1^2) - 0.0129 * (x2*x1) ...
        + 0.0796 * (x2^2) - 0.0634 * (x3*x1) - 0.0257 * (x3*x2) + 0.0877 * (x3^2) - 0.0521 * (x4*x1) ...
        + 0.00156 * (x4*x2) + 0.00198 * (x4*x3) + 0.0184 * (x4^2);

    % Second original objective function
    Xcc =  0.758+ 0.358 * x1 - 0.807 *x2 + 0.0925 * x3 - 0.0468 * x4 - 0.172 * (x1^2) + 0.0106 * (x2*x1) ...
        + 0.0697* (x2^2) - 0.146 * (x3*x1) - 0.0416 * (x3*x2) + 0.102 * (x3^2) - 0.0694 * (x4*x1) ...
        - 0.00503 * (x4*x2) + 0.0151 * (x4*x3) + 0.0173 * (x4^2);


    % Third original objective function
    TW4 =  0.370 -0.205 * x1 + 0.0307 * x2 + 0.108 * x3 + 1.019  * x4 - 0.135  * (x1^2) + 0.0141  * (x2*x1) ...
        + 0.0998 * (x2^2) + 0.208  * (x3*x1) - 0.0301 * (x3*x2) - 0.226 * (x3^2) + 0.353* (x4*x1) ...
        - 0.0497 * (x4*x3) - 0.423 * (x4^2) + 0.202 * (x2*(x1^2)) -0.281 * (x3*(x1^2)) - 0.342 * (x1*(x2^2)) ...
        - 0.245 * (x3*(x2^2)) + 0.281 * (x2*(x3^2)) - 0.184 * (x2*(x4^2)) + 0.281 * (x3*x2*x1)   ;

    % Fourth original objective function
    TTmax =   0.153 - 0.322 * x1 + 0.396 * x2 + 0.424 * x3 + 0.0226 * x4 + 0.175  * (x1^2) + 0.0185 * (x2*x1) ...
        - 0.0701 * (x2^2) - 0.251  * (x3*x1) + 0.179  * (x3*x2) + 0.0150  * (x3^2) + 0.0134  * (x4*x1) ...
        + 0.0296 * (x4*x2) + 0.0752  * (x4*x3) + 0.0192 * (x4^2);

    f(1) = TFmax;  % minimization
    f(2) = TW4; % minimization
    f(3) = TTmax; % minimization
    f(4) =  Xcc; % minimization

end



%% Five objective
% Locating a pollution monitoring

if RealWorldProb == 4
    f = zeros(1,M);
    x1 = x(1);
    x2 = x(2);

    j1=Fx(x1,x2);
    j2=Fx(x1-1.2, x2-1.5);
    j3=Fx(x1+0.3, x2-3.0);
    j4=Fx(x1-1.0, x2-0.5);
    j5=Fx(x1-0.5, x2-1.7);

    f(1) = j1;
    f(2) = j2;
    f(3) = j3;
    f(4) = j4;
    f(5) = j5;
end

    function u=U1(x1,x2)
        u=3*(1-x1)^2*exp(-x1^2-(x2+1)^2);
    end

    function u=U2(x1,x2)
        u=-10*(x1/4-x1^3-x2^5)*exp(-x1^2-x2^2);
    end

    function u=U3(x1,x2)
        u=(1/3)*exp(-(x1+1)^2-x2^2);
    end

    function U=Fx(x1,x2)
        u1=U1(x1,x2);
        u2=U2(x1,x2);
        u3=U3(x1,x2);
        U=-u1-u2-u3+10;
    end

% Ultra-wideband Antenna Design

if RealWorldProb == 5
    f = zeros(1,M);
    l1 = x(1);
    w1 = x(2);
    l2 = x(3);
    w2 = x(4);
    a1 = x(5);
    b1 = x(6);
    a2 = l1 * w1 * l2 * w2;
    b2 = l1 * w1 * l2 * a1;
    d2 = w1 * w2 * a1 * b1;

    F1 = 502.94 - 27.18 * ((w1 - 20.0) / 0.5) + 43.08 * ((l1 - 20.0) / 2.5) + 47.75 * (a1 - 6.0) ...
          + 32.25 * ((b1 - 5.5) / 0.5) + 31.67 * (a2 - 11.0) - 36.19 * ((w1 - 20.0) / 0.5) * ((w2 - 2.5) / 0.5) ...
          - 39.44 * ((w1 - 20.0) / 0.5) * (a1 - 6.0) + 57.45 * (a1 - 6.0) * ((b1 - 5.5) / 0.5);


    F2 = 130.53 + 45.97 * ((l1 - 20.0) / 2.5) - 52.93 * ((w1 - 20.0) / 0.5) - 78.93 * (a1 - 6.0) + 79.22 * (a2 - 11.0) ...
        + 47.23 * ((w1 - 20.0) / 0.5) * (a1 - 6.0) - 40.61 * ((w1 - 20.0) / 0.5) * (a2 - 11.0) ...
        - 50.62 * (a1 - 6.0) * (a2 - 11.0);

    F3 = 203.16 - 42.75 * ((w1 - 20.0) / 0.5) + 56.67 * (a1 - 6.0) + 19.88 * ((b1 - 5.5) / 0.5) - 12.89 * (a2 - 11.0) ...
        - 35.09 * (a1 - 6.0) * ((b1 - 5.5) / 0.5) - 22.91 * ((b1 - 5.5) / 0.5) * (a2 - 11.0);

    F4 = 0.76 - 0.06 * ((l1 - 20.0) / 2.5) + 0.03 * ((l2 - 2.5) / 0.5) + 0.02 * (a2 - 11.0) - 0.02 * ((b2 - 6.5) / 0.5) ...
        - 0.03 * ((d2 - 12.0) / 0.5) + 0.03 * ((l1 - 20.0) / 2.5) * ((w1 - 20.0) / 0.5) ...
        - 0.02 * ((l1 - 20.0) / 2.5) * ((l2 - 2.5) / 0.5) + 0.02 * ((l1 - 20.0) / 2.5) * ((b2 - 6.5) / 0.5);


    F5 = 1.08 - 0.12 * ((l1 - 20.0) / 2.5) - 0.26 * ((w1 - 20.0) / 0.5) - 0.05 * (a2 - 11.0) - 0.12 * ((b2 - 6.5) / 0.5) ...
        + 0.08 * (a1 - 6.0) * ((b2 - 6.5) / 0.5) + 0.07 * (a2 - 6.0) * ((b2 - 5.5) / 0.5);

    f(1) = F1;  % minimization
    f(2) = -F2; % maximization
    f(3) = -F3; % maximization
    f(4) = -F4; % maximization
    f(5) = F5;  % minimization
end

%% Machining Problem

if RealWorldProb == 6


    f = zeros(1,M);
    x1 = x(1);
    x2 = x(2);
    x3 = x(3);

    % First original objective function
    F1 = -7.49 + 0.441 * x1 - 1.16 * x2 + 0.61 * x3;
    % Second original objective function
    F2 = -4.31 + 0.92 * x1 - 0.16 * x2 + 0.43 * x3;

    % Third original objective function
    F3 = 21.90 - 1.94 * x1 - 0.30 * x2 - 1.04 * x3;

    % Fourth original objective function
    F4 = -11.331 + x1 + x2+ x3;

    % Constraint functions
    g(1) =  -3.17 + 0.44 * x1 - 1.16 * x2 + 0.61 * x3;
    g(2) =  -8.04 - 0.92 * x1 - 0.16 * x2 + 0.43 * x3;
    g(3) =  18.50 + 1.94 * x1 - 0.30 * x2 - 1.04 * x3;

    % Calculate the constratint violation values
    g(g>=0)=0;
    g(g<0)=-g(g<0);

    F5 = g(1) + g(2) + g(3);

    f(1) = F1;  % minimization
    f(2) = -F2; % maximization
    f(3) = -F3; % maximization
    f(4) = -F4; % maximization
    f(5) = F5;  % minimization
end


%% six objective
% Single Pass Work roll design problem

if RealWorldProb == 7      %% Work roll design problem
    f = zeros(1,M);
    x1 = x(1);
    x2 = x(2);
    x3 = x(3);
    x4 = x(4);
    x5 = x(5);
    x6 = x(6);
    x7 = x(7);

    % First original objective function
    F1 = (-370.8659 + 3.92666667*x1 + 0.046222222*(x1^2) + 3.02845679 * x2 - 0.00130938 * (x2^2) ...
        + 0.0000001*x3 - 0.025*(x3^2) - 7.0603175*x4+ 0.085079365* (x4^2) + 26.9230797 * x5 ...
        + 3.44362939 * (x5^2) + 3.99055556 * x6 - 0.04194444 * (x6^2) - 0.801944 * x7 + 0.004701389 *(x7^2));
    % Second original objective function
    F2 = (140.63997 - 10.082111*x1 + 0.064200000*(x1^2) - 1.2915963*x2 + 0.002292222*(x2^2) ...
        + 0.0014444*x3 -0.000003333*(x3^2) + 12.1149569*x4 -0.21604354 *(x4^2) -387.34458*x5 ...
        +145.751168*(x5^2)-2.6677500*x6 + 0.0386875*(x6^2)-1.4585556*x7+0.01198229*(x7^2));
    % Third original objective function
    F3 =  (-819.98558 + 9.97380000*x1 - 0.31336444*(x1^2) + 1.43803309*x2 - 0.59030*10^-3 * (x2^2) ...
        - 0.13506667 * x3 + 0.095348889 * (x3^2) - 5.1424209 * x4 + 0.062201542 * (x4^2) + 52.8477445 * x5 ...
        - 23.073031 * (x5^2) + 0.050088889 * x6 - 0.00849611 * (x6^2) - 0.22464444*x7 + 0.001426597 * (x7^2));
    % Fourth original objective function
    F4 =  (913.51841 - 18.435556 * x1 + 0.508400000* (x1^2) - 5.0893000*x2 + 0.002138444* (x2^2) ...
        - 3.9332778 * x3 - 0.13521667 * (x3^2) + 14.6337279 * x4 - 0.18028299 * (x4^2) - 248.51971 * x5 ...
        + 101.248057 * (x5^2) + 0.1710833 * x6 + 0.017137500 * (x6^2) + 0.108888*x7 - 0.17812 *10^-3 * (x7^2));
    % Fifth original objective function
    F5 =  (-533.55904 + 9.74111*x1 - 0.35888889 * (x1^2) + 1.00235802 * x2 - 0.40321 * 10^-3 *  (x2^2) ...
        - 0.51055556 * x3 + 0.0949444* (x3^2) - 3.9777324 * x4 + 0.04591383 *  (x4^2) + 51.7361959 * x5 ...
        - 28.708807 *  (x5^2) - 1.0575000* x6 + 0.001652778 *  (x6^2) -0.29222* x7 + 0.0022048 * (x7^2));




    % Sixth original objective function
    F6 =  (316.50677 - 19.781444*x1 + 0.553933333 *  (x1^2) - 4.0415037 * x2 + 0.001683704 *  (x2^2) ...
        - 5.6866667 * x3 - 0.07520000 *  (x3^2) + 11.4528209 * x4 - 0.13340408 *  (x4^2) - 199.10688 * x5 ...
        + 97.5171611 *  (x5^2) + 0.867388889 * x6 + 0.009866667 *  (x6^2) + 0.738388889 * x7 - 0.00434792 *  (x7^2));

    f(1) = F1;  % minimization
    f(2) = F2;  % minimization
    f(3) = F3;  % minimization
    f(4) = F4;  % minimization
    f(5) = F5;  % minimization
    f(6) = F6;  % minimization

end


% Water resource planning problem problem
if RealWorldProb == 8
    f = zeros(1,M);
    x1 = x(1);
    x2 = x(2);
    x3 = x(3);

    % First original objective function
    f(1) = 106780.37 * (x2 + x3) + 61704.67 ;
    % Second original objective function
    f(2) = 3000 * x1 ;
    % Third original objective function
    f(3) = 305700 * 2289 * x2 / power(0.06*2289, 0.65) ;
    % Fourth original objective function
    f(4) = 250 * 2289 * exp(-39.75*x2+9.9*x3+2.74) ;
    % Fifth original objective function
    f(5) = 25 * (1.39 /(x1*x2) + 4940*x3 -80) ;

    % Constraint functions
    g(1) = 1 - (0.00139/(x1*x2)+4.94*x3-0.08);
    g(2) = 1 - (0.000306/(x1*x2)+1.082*x3-0.0986);
    g(3) = 50000 - (12.307/(x1*x2) + 49408.24*x3+4051.02);
    g(4) = 16000 - (2.098/(x1*x2)+8046.33*x3-696.71);
    g(5) = 10000 - (2.138/(x1*x2)+7883.39*x3-705.04);
    g(6) = 2000 - (0.417*x1*x2 + 1721.26*x3-136.54);
    g(7) = 550 - (0.164/(x1*x2)+631.13*x3-54.48);

    % Calculate the constratint violation values
    g(g>=0)=0;
    g(g<0)=-g(g<0);

    f(6) = g(1) + g(2) + g(3) + g(4) + g(5) + g(6) + g(7);

end


%% seven objective
% Water and oil repellent fabric development

if RealWorldProb == 9
    f = zeros(1,M);
    x1 = x(1);
    x2 = x(2);
    x3 = x(3);

    %  /* maximization */
    WCA = -1331.04 + 1.99 * x1 + 0.33 * x2 + 17.12 * x3 - 0.02 * (x1^2) - 0.05 * (x3^2) - 15.33;


    % /* maximization */
    OCA = -4231.14 + 4.27 * x1 + 1.50 * x2 + 52.30 * x3 - 0.04 * x1*x2 - 0.04 * (x1^2) -0.16 * (x3^2) - 29.33;

    % /* maximization */
    AP = 1766.80 - 32.32 * x1 - 24.56 *x2 - 10.48 * x3 + 0.24 * x1*x3 + 0.19 * x2*x3 ...
        - 0.06 * (x1^2) -0.10 * (x3^2) - 413.33 ;

    % /* maximization */
    CRA = -2342.13 - 1.556 * x1 + 0.77 * x2 + 31.14 * x3 + 0.03 * (x1^2) - 0.10 *  (x3^2) - 73.33;

    % /* minimization */
    Stiffness = 9.34 + 0.02 * x1 - 0.03 * x2 - 0.03 * x3 - 0.001 * (x1^2) + 0.0009 * (x2^2) + 0.22;

    % /* maximization */
    Tear = 1954.71 + 14.246 * x1 + 5.00 * x2 - 4.30 * x3 - 0.22 * (x1^2) - 0.33 * (x2^2) - 8413.33;

    % /* maximization */
    Tensile = 828.16 + 3.55 * x1 + 73.65 * x2 + 10.80 * x3 - 0.56 * x2*x3 + 0.20 *x2*x2 - 2814.83;

    f(1) = -WCA;
    f(2) = -OCA;
    f(3) = -AP;
    f(4) = -CRA;
    f(5) = Stiffness;
    f(6) = -Tear;
    f(7) = -Tensile;

end

%% nine objective
% car cab design problem
if RealWorldProb == 10
    f = zeros(1,M);
    x0 = x(1);
    x1 = x(2);
    x2 = x(3);
    x3 = x(4);
    x4 = x(5);
    x5 = x(6);
    x6 = x(7);

    x7 = 0.006 * randn + 0.345;
    x8 = 0.006 * randn + 0.192;
    x9 = 10 * randn + 0.0;
    x10 = 10 * randn + 0.0;

    f(1) = 1.98 + 4.9 * x0 + 6.67 * x1 + 6.98 * x2 +  4.01 * x3 +  1.75 * x4 +  0.00001 * x5  +  2.73 * x6;

    f(2) = max(0.0, (1.16 - 0.3717* x1 * x3 - 0.00931 * x1 * x9 - 0.484 * x2 * x8 + 0.01343 * x5 * x9 )/1.0) ;

    f(3) = max(0.0, (0.261 - 0.0159 * x0 * x1 - 0.188 * x0 * x7 - 0.019 * x1 * x6 + 0.0144 * x2 * x4 + 0.87570001 * x4 * x9 + 0.08045 * x5 * x8 + 0.00139 * x7 * x10 + 0.00001575 * x9 * x10)/0.32);

    f(4) = max(0.0, (0.214 + 0.00817 * x4  - 0.131 * x0 * x7 - 0.0704 * x0 * x8 + 0.03099 * x1 * x5 - 0.018 * x1 * x6 + 0.0208 * x2 * x7 + 0.121 * x2 * x8 - 0.00364 * x4 * x5 + 0.0007715 * x4 * x9 - 0.0005354 * x5 * x9 + 0.00121 * x7 * x10 + 0.00184 * x8 * x9 - 0.018 * x1 * x1)/0.32);

    f(5) =  max(0.0, (0.74 - 0.61* x1 - 0.163 * x2 * x7 + 0.001232 * x2 * x9 - 0.166 * x6 * x8 + 0.227 * x1 * x1)/0.32);

    temp = (( 28.98 + 3.818 * x2 - 4.2 * x0 * x1 + 0.0207 * x4 * x9 + 6.63 * x5 * x8 - 7.77 * x6 * x7 + 0.32 * x8 * x9) + (33.86 + 2.95 * x2 + 0.1792 * x9 - 5.057 * x0 * x1 - 11 * x1 * x7 - 0.0215 * x4 * x9 - 9.98 * x6 * x7 + 22 * x7 * x8) + (46.36 - 9.9 * x1 - 12.9 * x0 * x7 + 0.1107 * x2 * x9) )/3;

    f(6) =  max(0.0, temp/32);

    f(7) =  max(0.0, (4.72 - 0.5 * x3 - 0.19 * x1 * x2 - 0.0122 * x3 * x9 + 0.009325 * x5 * x9 + 0.000191 * x10 * x10)/4.0);

    f(8) =  max(0.0, (10.58 - 0.674 * x0 * x1 - 1.95  * x1 * x7  + 0.02054  * x2 * x9 - 0.0198  * x3 * x9  + 0.028  * x5 * x9)/9.9) ;

    f(9) =  max(0.0, (16.45 - 0.489 * x2 * x6 - 0.843 * x4 * x5 + 0.0432 * x8 * x9 - 0.0556 * x8 * x10 - 0.000786 * x10 * x10)/15.7);
end

% Multi Pass Work roll design problem

if RealWorldProb == 11

    x1 = x(1);
    x2 = x(2);
    x3 = x(3);
    x4 = x(4);
    x5 = x(5);
    x6 = x(6);
    x7 = x(7);

    %% Pass-1
    % First original objective function
    F1 = (-3078.7483 + 3.92666667 * x1 + 0.046222222 * (x1^2) + 2.39944444 * x2 + 4.90000000 * x3 ...
        - 0.02511111 * (x3^2) - 7.0603175 * x4 + 0.085079365 * (x4^2) + 433.703704 * x5 ...
         + 3.99055556 * x6 - 0.04194444 * (x6^2) - 0.80194444 * x7 + 0.004701389 * (x7^2));
    % Second original objective function
    F2 = (5551.59887 - 9.771 * x1 + 0.419755556 * (x1^2) -4.1428889 * x2 + 1.91477778 * x3 ...
        - 0.18294444 * (x3^2) + 17.2142766 * x4 - 0.21967166 * (x4^2) - 2961.7685 * x5 ...
        - 3.3344167 * x6 + 0.044243056 * (x6^2) - 1.6252222 * x7 + 0.013371181 * (x7^2));


    %% Pass-2
    x8  = x(8);
    x9  = x(9);
    x10 = x(10);
    x11 = x(11);
    x12 = x(12);
    x13 = x(13);
    x14 = x(14);

 
    % Third original objective function
    F3 = (-74017.666 + 3.92666667 * x8 + 0.046222222 * (x8^2) + 124.916389 * x9- 0.05286111 * (x9^2) ...
        + 4.9 * x10 - 0.02511111 * (x10^2) - 9.3007256 * x11 + 0.112235828 * (x11^2) + ...
        2560.67901 * x12 - 4322.5309 * (x12^2) + 1.07972222 * x13 - 0.02115278 * (x13^2) ...
        - 0.90302431 * x14 + 0.004701389 * (x14^2));
    % Fourth original objective function
    F4 = (-69381.097 - 9.7710000 * x8 + 0.419755556 * (x8^2) + 120.479931 * x9 - 0.05048750 * (x9^2) ...
        + 1.91477778 * x10 - 0.18294444 * (x10^2) + 37.1468753 * x11 - 0.46127891 * (x11^2) ... 
        - 28760.889 * x12 + 53404.1667 * (x12^2) + 22.5628611 * x13 - 0.14073750 * (x13^2) ...
        - 1.9127026 * x14 + 0.013371181 * (x14^2));

    %% Pass-3
    x15  = x(15);
    x16  = x(16);
    x17  = x(17);
    x18  = x(18);
    x19  = x(19);
    x20  = x(20);
    x21  = x(21);
 
    % Fifth original objective function

    F5 = (-90392.107 + 3.92666667 * x15 + 0.046222222 * (x15^2) + 163.144722 * x16 - 0.07365278 * (x16^2) ...
        + 4.9 * x17 - 0.02511111 * (x17^2) - 7.0603175 * x18 + 0.085079365 * (x18^2) ...
        + 68.7345679 * x19 + 297.839506 * (x19^2) + 3.99055556 * x20 - 0.04194444 * (x20^2) ...
        - 0.95991111 * x21 + 0.004701389 * (x21^2));

    % Sixth original objective function

    F6 = (167054.217 - 9.771 * x15 + 0.419755556 * (x15^2) - 297.75003 * x16 + 0.134493056 * (x16^2) + ...
         1.91477778 * x17 - 0.18294444 * (x17^2) + 17.2142766 * x18 - 0.21967166 * (x18^2) ...
         - 11074.571 * x19 + 12297.3765 * (x19^2) - 3.3344167 * x20 + 0.044243056 * (x20^2) ...
         - 2.0744939 * x21 + 0.013371181 * (x21^2));


     %% Pass-4
    x22  = x(22);
    x23  = x(23);
    x24  = x(24);
    x25  = x(25);
    x26  = x(26);
    x27  = x(27);
    x28  = x(28);

    % Seventh original objective function
    F7 = (-78565.254 + 3.92666667 * x22 + 0.046222222 * (x22^2) + 152.096806 * x23 - 0.07365278 * (x23^2) ...
        + 4.9 * x24 - 0.02511111 * (x24^2) - 7.0603175 * x25 + 0.085079365 * (x25^2) - 80.185185 * x26 ...
        + 297.839506 * (x26^2) + 3.99055556 * x27 - 0.04194444 * (x27^2) - 0.99705208 * x28 + 0.004701389 * (x28^2));


    % Eight original objective function

    F8 = (149025.120 - 9.771 * x22 + 0.419755556 * (x22^2) - 277.57607 * x23 + 0.134493056 * (x23^2) ...
        + 1.91477778 * x24 - 0.18294444 * (x24^2) + 17.2142766 * x25 - 0.21967166 * (x25^2) - 17223.259 * x26 ...
        + 12297.3765 * (x26^2) - 3.3344167 * x27 + 0.044243056 * (x27^2) - 2.1801262 * x28 + 0.013371181 * (x28^2));

    %% Pass-5
    x29  = x(29);
    x30  = x(30);
    x31  = x(31);
    x32  = x(32);
    x33  = x(33);
    x34  = x(34);
    x35  = x(35);

    % Ninth original objective function

    F9 = (-868.02142 + 3.92666667 * x29 + 0.046222222 * (x29^2) + 0.926388889 * x30 +  ...
        + 4.9 * x31 - 0.02511111 * (x31^2) - 7.0603175 * x32 + 0.085079365 * (x32^2) - 324.41358 * x33 ...
        + 297.839506 * (x33^2) + 3.99055556 * x34 - 0.0419333 * (x34^2) - 1.0194307 * x35 + 0.004701389 *(x35^2));

    % tenth original objective function

    F10 = (16371.3330 - 9.771 * x29 + 0.419755556 * (x29^2) - 1.4530278 * x30 + 0.00000000 * (x30^2) ...
        + 1.91477778 * x31 - 0.18294444 * (x31^2) + 17.2142766 * x32 - 0.21967166 * (x32^2) - 27307.108 * x33 ...
        + 12297.3765 * (x33^2) - 3.3344167 * x34 + 0.044243056 * (x34^2) - 2.2437730 * x35 + 0.013371181 * (x35^2));

    f(1)  = F1;  % minimization
    f(2)  = F2;  % minimization
    f(3)  = F3;  % minimization
    f(4)  = F4;  % minimization
    f(5)  = F5;  % minimization
    f(6)  = F6;  % minimization
    f(7)  = F7;  % minimization
    f(8)  = F8;  % minimization
    f(9)  = F9;  % minimization
    f(10) = F10;  % minimization


end

end