% The code of NSGA-II accomplished on MATLAB
clc;format compact;tic;
%-----------------------------------------------------------------------------------------
% Problem Selection and Problem Paramaters
for RealWorldProb = 1 : 11   % Real-world Problems

    if RealWorldProb == 1    %% car side impact design problem
        M = 4;
        D = 7;
        MinValue = [0.5 0.45 0.5 0.5 0.875 0.4 0.4];
        MaxValue = [1.5 1.35 1.5 1.5 2.625 1.2 1.2];
    elseif RealWorldProb ==  2   %% RE42 -- conceptual marine design
        M = 4;
        D = 6;
        MinValue = [150.0 20.0 13.0 10.0 14.0 0.63];
        MaxValue = [274.32 32.31 25.0 11.71 18.0 0.75];

    elseif RealWorldProb == 3    %% Liquid-rocket single element injector design
        M = 4;
        D = 4;
        MinValue = [0  0  -40  0.01];
        MaxValue = [20 25   0  0.02];
    elseif RealWorldProb ==  4   %% Locating a pollution monitoring
        M = 5;
        D = 2;
        MinValue = [-4.9,-3.5];
        MaxValue = [3.2,6];

    elseif RealWorldProb ==  5   %% Ultra-wideband Antenna Design
        M = 5;
        D = 6;
        MinValue = [17.5 17.5 2 2 5 5];
        MaxValue = [22.5 22.5 3 3 7 6];
    elseif RealWorldProb ==  6   %% Machining Problem
        M = 5;
        D = 3;
        MinValue = [ 6.40 0.69 3.91];
        MaxValue = [ 7.09 2.89 4.61];

    elseif RealWorldProb ==  7  %% Single-pass Work roll design problem
        M = 6;
        D = 7;
        MinValue = [5 950 15 10 0.14 40 20];
        MaxValue = [15 1250 50 30 1.256 80 100];

    elseif RealWorldProb ==  8    %% water resource planning problem problem
        M = 6;
        D = 3;
        MinValue = [0.01 0.01 0.01];
        MaxValue = [0.45 0.10 0.10];
    elseif RealWorldProb ==  9   %% Water and oil repellent fabric development
        M = 7;
        D = 3;
        MinValue = [10 10 150];
        MaxValue = [50 50 170];
    elseif RealWorldProb ==  10   %% car cab design problem
        M = 9;
        D = 7;
        MinValue = [0.5 0.45 0.5 0.5 0.875 0.4 0.4];
        MaxValue = [1.5 1.35 1.5 1.5 2.625 1.2 1.2];
    elseif RealWorldProb ==  11   %% Multi-pass Work roll design problem
        M = 10;
        D = 35;
        MinValue = [5 1230 10 15 0.14 40 65 5 1155 10 15 0.17 40 75.75 5 1080 10 15 0.32 40 82.25 5 1005 10 15 0.57 40 86.20 5 950 10 15 0.98 40 88.58];
        MaxValue = [15 1250 30 50 0.2 80 75 15 1195 30 50 0.29 80 85.75 15 1120 30 50 0.44 80 92.25 15 1045 30 50 0.69 80 96.20 15 970 30 50 1.1 80 98.58];
    end

    Generations = 250;

    if M == 2
        N = 100;            % population size
    elseif M == 3
        N = 105;
    elseif M == 4
        N = 120;
    elseif M == 5
        N = 126;
    elseif M == 6
        N = 132;
    elseif M == 7
        N = 112;
    elseif M == 8
        N = 156;
    elseif M == 9
        N = 210;
    elseif M == 10
        N = 275;
    elseif M == 15
        N = 240;
    elseif M == 20
        N = 230;
    end

    Boundary   = [MaxValue;MinValue];
    Runs = 30;


    r    = zeros(1,2*N)-1;	% parameter r for each front
    t    = zeros(1,2*N)-1; 	% parameter t for each front

    for run = 1 : 30
        tic
        %-----------------------------------------------------------------------------------------
        % Initialization
        Population            = repmat(MinValue,N,1) + repmat(MaxValue - MinValue,N,1).*rand(N,D); % initial population
        for i = 1 :  N
            FunctionValue(i,:)        = F_Real_UC(Population(i,:),RealWorldProb,M);    % calculate the objective values
        end
        FrontValue            = ENS(FunctionValue,'all');                 % non-dominated sort using A-ENS
        KneePoint             = zeros(1,N);                                 % whether a solution is a knee point
        %-----------------------------------------------------------------------------------------
        % Main iterations
        for Gene = 1 : Generations
            % generate offsprings
            MatingPool            = F_mating(Population,FunctionValue,FrontValue,KneePoint);% mating selection
            Offspring             = GA(MatingPool,{1,20,1,20},MinValue,MaxValue);
            for i = 1 :  size(Offspring,1)
                NewFunctionValue(i,:)  = F_Real_UC(Offspring(i,:),RealWorldProb,M);    % calculate the objective values
            end

            Population            = [Population;Offspring];
            FunctionValue         = [FunctionValue;NewFunctionValue];

            % environmental selection
            [FrontValue,MaxFront]    = ENS(FunctionValue,'half');                          	% non-dominated sort (only the first half)
            [KneePoint,Distance,r,t] = F_kneepoint(FunctionValue,FrontValue,MaxFront,r,t);	% finding knee point
            Next = F_choose(FunctionValue,FrontValue,MaxFront,KneePoint,Distance,N);            % environmental selection

            % population for next generation
            Population    = Population(Next,:);     % solutions on decision space
            FunctionValue = FunctionValue(Next,:);  % solutions on objective space
            FrontValue    = FrontValue(Next);       % the front number of each solution
            KneePoint     = KneePoint(Next);        % whether a solution is a knee point
            Gene
        end
        %-----------------------------------------------------------------------------------------
        % Result saving
        F_output(Population,toc,'Pi_MOEA_Real',RealWorldProb,M,run);
    end
    clear all;clc
end

